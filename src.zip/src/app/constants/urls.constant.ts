export const urls = {
    books: 'books.json'
};