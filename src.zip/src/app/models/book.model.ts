export class Book {
  code: string;
  name: string;
  thumbnail: string;
  author: string;
}
